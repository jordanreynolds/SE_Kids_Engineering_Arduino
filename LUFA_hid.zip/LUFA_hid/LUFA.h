#ifndef __LUFA_H__
#define __LUFA_H__

/*
 * This file is here only because Arduino wants it...
 */

//#include <Platform.h>
#define F_USB F_CPU

#include <LUFA/Drivers/USB/USB.h>

#endif